package net.codejava.service;

import net.codejava.model.AppUser;
import net.codejava.model.RefreshToken;
import net.codejava.repository.AppUserRepository;
import net.codejava.repository.RefreshTokenRepository;
import net.codejava.util.JwtUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;

@Service
@Transactional
public class RefreshTokenService {

    private final RefreshTokenRepository tokenRepo;
    private final AppUserRepository userRepo;
    private final JwtUtil jwtUtil;

    private final long refreshExpirationMs;

    public RefreshTokenService(RefreshTokenRepository tokenRepo,
                               AppUserRepository userRepo,
                               JwtUtil jwtUtil,
                               @Value("${app.refresh-expiration-ms:604800000}") long refreshExpirationMs) {
        this.tokenRepo = tokenRepo;
        this.userRepo = userRepo;
        this.jwtUtil = jwtUtil;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    /* ---------- Public API ---------- */

    /** Issue a new refresh token for user; revoke all existing active tokens for this user. */
    public String issueAndStore(String username, String ip, String ua) {
        AppUser user = userRepo.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Cannot find user: " + username));

        // Policy: single active refresh per user (easy). Remove if you want multi-device support.
        tokenRepo.revokeAllActiveByUser(user, now());

        String opaque = newOpaque();
        String hash = sha256Url(opaque);

        RefreshToken r = new RefreshToken();
        r.setUser(user);
        r.setTokenHash(hash);
        r.setExpiryDate(new Date(System.currentTimeMillis() + refreshExpirationMs));
        r.setCreatedAt(now());
        r.setCreatedByIp(ip);
        r.setUserAgent(ua);
        r.setRotationCounter(0);
        tokenRepo.save(r);

        return opaque; // put in HttpOnly cookie
    }

    /** Validate refresh token (from cookie/body), rotate it, and mint a new access JWT. */
    public RefreshResult refresh(String opaque, String ip, String ua) {
        String hash = sha256Url(opaque);
        RefreshToken current = tokenRepo.findActiveByHash(hash, now())
                .orElseThrow(() -> new IllegalStateException("Invalid or expired refresh token"));

        // ---- Reuse detection (simple): if someone tries to reuse a rotated token hash,
        // it won't be active (revokedAt != null) and the query above will fail.
        // If you want *family* revocation, keep rotatedFromId chain & revokeAllActiveByUser.

        // Mint new access
        String username = current.getUser().getUsername();
        String newAccess = jwtUtil.generateToken(username);

        // Rotate refresh: revoke current, insert next
        current.setRevokedAt(now());

        String nextOpaque = newOpaque();
        String nextHash = sha256Url(nextOpaque);

        RefreshToken next = new RefreshToken();
        next.setUser(current.getUser());
        next.setTokenHash(nextHash);
        next.setExpiryDate(new Date(System.currentTimeMillis() + refreshExpirationMs));
        next.setCreatedAt(now());
        next.setCreatedByIp(ip);
        next.setUserAgent(ua);
        next.setRotationCounter((current.getRotationCounter() == null ? 0 : current.getRotationCounter()) + 1);
        next.setRotatedFromId(current.getId());
        tokenRepo.save(next);

        return new RefreshResult(newAccess, nextOpaque, (int) (refreshExpirationMs / 1000));
    }

    /** Logout all sessions for user (revoke all active refresh tokens). */
    public void revokeAllForUser(String username) {
        AppUser user = userRepo.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Cannot find user: " + username));
        tokenRepo.revokeAllActiveByUser(user, now());
    }

    /* ---------- Helpers ---------- */

    private static final SecureRandom RNG = new SecureRandom();

    private static String newOpaque() {
        byte[] b = new byte[32]; // 256-bit
        RNG.nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    private static String sha256Url(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(d);
        } catch (Exception e) {
            throw new RuntimeException("SHA-256 unsupported", e);
        }
    }

    private static Date now() { return new Date(); }

    /* ---------- Result DTO ---------- */
    public record RefreshResult(String newAccessJwt, String newOpaque, int maxAgeSec) {}
}
