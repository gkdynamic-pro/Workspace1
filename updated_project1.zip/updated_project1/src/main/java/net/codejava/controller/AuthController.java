package net.codejava.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import net.codejava.service.RefreshTokenService;
import net.codejava.service.TokenBlacklistService;
import net.codejava.util.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.util.HashSet;
import java.util.Set;
import java.util.Map;

@RestController
@RequestMapping
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final TokenBlacklistService tokenBlacklistService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder encoder;
    private final AppUserRepository userRepository;
    private final RefreshTokenService refreshTokenService;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil,
                          PasswordEncoder encoder,
                          AppUserRepository userRepository,
                          TokenBlacklistService tokenBlacklistService,
                          RefreshTokenService refreshTokenService) {
        this.authenticationManager = authenticationManager;
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtUtil = jwtUtil;
        this.encoder = encoder;
        this.userRepository = userRepository;
        this.refreshTokenService = refreshTokenService;
    }

    /* -------------------- AUTHENTICATE -------------------- */
    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponse> authenticate(@RequestBody AuthRequest request,
                                                     HttpServletRequest httpReq,
                                                     HttpServletResponse httpRes) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(401).build();
        }

        // short-lived access JWT (header-based)
        String accessToken = jwtUtil.generateToken(request.getUsername());

        // DB-backed, hashed refresh token — return OPAQUE value to set as HttpOnly cookie
        String opaque = refreshTokenService.issueAndStore(request.getUsername(), ip(httpReq), ua(httpReq));

        // Set/rotate cookie
        addRefreshCookie(httpRes, opaque, /* 7 days */ 7 * 24 * 3600);

        return ResponseEntity.ok(new AuthResponse(accessToken));
    }

    /* -------------------- SIGNUP -------------------- */
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest().body(new Message("Username already taken"));
        }
        Set<String> roles = request.getRoles();
        if (roles == null || roles.isEmpty()) {
            roles = new HashSet<>();
            roles.add("USER");
        }
        AppUser user = new AppUser();
        user.setUsername(request.getUsername());
        user.setPassword(encoder.encode(request.getPassword()));
        user.setRoles(roles);
        userRepository.save(user);
        return ResponseEntity.ok(new Message("User registered successfully"));
    }

    /* -------------------- REFRESH -------------------- */
    // Optional body fallback if you want Postman to pass refresh token in JSON
    @Data static class RefreshBody { private String refreshToken; }

    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refresh(@RequestBody(required = false) RefreshBody body,
                                                @CookieValue(value = "refreshToken", required = false) String cookieToken,
                                                HttpServletRequest httpReq,
                                                HttpServletResponse httpRes) {
        // prefer body if present; else cookie
        String opaque = (body != null && body.getRefreshToken() != null && !body.getRefreshToken().isBlank())
                ? body.getRefreshToken() : cookieToken;

        if (opaque == null || opaque.isBlank()) {
            return ResponseEntity.status(403).build();
        }

        // Service validates in DB (by hash), ROTATES refresh, and mints new access JWT
        var out = refreshTokenService.refresh(opaque, ip(httpReq), ua(httpReq));

        // Set rotated refresh cookie
        addRefreshCookie(httpRes, out.newOpaque(), out.maxAgeSec());

        // Return new short-lived access JWT
        return ResponseEntity.ok(new AuthResponse(out.newAccessJwt()));
    }

    /* -------------------- LOGOUT -------------------- */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().body(new Message("Missing Authorization header"));
        }
        String token = auth.substring(7);

        // Blacklist the current access token by JTI (TTL = remaining lifetime)
        String jti = jwtUtil.extractJti(token);
        java.util.Date exp = jwtUtil.getExpirationDate(token);
        long ttlSeconds = Math.max(0, (exp.getTime() - System.currentTimeMillis()) / 1000);
        String key = "bl:access:" + (jti != null ? jti : Integer.toHexString(token.hashCode()));
        tokenBlacklistService.blacklist(key, ttlSeconds);

        // Revoke all active refresh tokens for this user (simple policy)
        String username = jwtUtil.extractUsername(token); // ensure JwtUtil has this method
        if (username != null) {
            refreshTokenService.revokeAllForUser(username);
        }

        // Clear cookie
        clearRefreshCookie(response);
        return ResponseEntity.ok(new Message("Logged out"));
    }

    /* -------------------- DTOs -------------------- */
    @Data static class AuthRequest { private String username; private String password; }

    @Data @AllArgsConstructor
    static class AuthResponse { private String jwt; }

    @Data static class SignupRequest { private String username; private String password; private Set<String> roles; }

    @Data @AllArgsConstructor
    static class Message { private String message; }

    /* -------------------- Helpers -------------------- */
    private static void addRefreshCookie(HttpServletResponse res, String opaque, int maxAgeSec) {
        var c = new jakarta.servlet.http.Cookie("refreshToken", opaque);
        c.setHttpOnly(true);
        c.setSecure(false);          // true in prod (HTTPS)
        c.setPath("/");
        c.setMaxAge(maxAgeSec);
        c.setAttribute("SameSite", "Lax"); // or "None" if cross-site
        res.addCookie(c);
    }

    private static void clearRefreshCookie(HttpServletResponse res) {
        var c = new jakarta.servlet.http.Cookie("refreshToken", "");
        c.setHttpOnly(true);
        c.setSecure(false);          // true in prod
        c.setPath("/");
        c.setMaxAge(0);
        c.setAttribute("SameSite", "Lax");
        res.addCookie(c);
    }

    private static String ip(HttpServletRequest r) {
        String xff = r.getHeader("X-Forwarded-For");
        return (xff != null) ? xff.split(",")[0].trim() : r.getRemoteAddr();
    }
    private static String ua(HttpServletRequest r) { return r.getHeader("User-Agent"); }
}
