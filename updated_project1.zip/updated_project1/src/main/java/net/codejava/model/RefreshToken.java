package net.codejava.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "refresh_tokens",
        indexes = {
                @Index(name = "ux_token_hash", columnList = "tokenHash", unique = true),
                @Index(name = "ix_user", columnList = "user_id")
        })
public class RefreshToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Hashed token (Base64url(SHA-256(raw)))
    @Column(nullable = false, length = 88, unique = true)
    private String tokenHash;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date expiryDate;

    @Temporal(TemporalType.TIMESTAMP)
    private Date revokedAt;         // null = active

    private Long rotatedFromId;     // parent token id (for chain)
    private Integer rotationCounter;// 0,1,2,...

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false)
    private Date createdAt;

    private String createdByIp;
    private String userAgent;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private AppUser user;

    // getters/setters

    public Long getId() { return id; }
    public String getTokenHash() { return tokenHash; }
    public void setTokenHash(String tokenHash) { this.tokenHash = tokenHash; }
    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date expiryDate) { this.expiryDate = expiryDate; }
    public Date getRevokedAt() { return revokedAt; }
    public void setRevokedAt(Date revokedAt) { this.revokedAt = revokedAt; }
    public Long getRotatedFromId() { return rotatedFromId; }
    public void setRotatedFromId(Long rotatedFromId) { this.rotatedFromId = rotatedFromId; }
    public Integer getRotationCounter() { return rotationCounter; }
    public void setRotationCounter(Integer rotationCounter) { this.rotationCounter = rotationCounter; }
    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
    public String getCreatedByIp() { return createdByIp; }
    public void setCreatedByIp(String createdByIp) { this.createdByIp = createdByIp; }
    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }
    public AppUser getUser() { return user; }
    public void setUser(AppUser user) { this.user = user; }
}
