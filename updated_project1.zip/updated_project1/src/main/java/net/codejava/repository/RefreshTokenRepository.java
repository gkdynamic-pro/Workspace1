package net.codejava.repository;

import net.codejava.model.AppUser;
import net.codejava.model.RefreshToken;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Optional;

@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    // Active = not revoked and not expired
    @Query("""
      select r from RefreshToken r
       where r.tokenHash = :hash
         and r.revokedAt is null
         and r.expiryDate > :now
    """)
    Optional<RefreshToken> findActiveByHash(@Param("hash") String tokenHash,
                                            @Param("now") Date now);

    @Modifying
    @Query("update RefreshToken r set r.revokedAt = :now where r.user = :user and r.revokedAt is null")
    int revokeAllActiveByUser(@Param("user") AppUser user, @Param("now") Date now);

    int deleteByUser(AppUser user); // keep if you want hard deletes (optional)
}
