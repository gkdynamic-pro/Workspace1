package net.codejava.service;

import net.codejava.dto.UserSummaryDTO;
import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
@Transactional
public class AppUserService {

    private final AppUserRepository repo;
    private final PasswordEncoder encoder;

    public AppUserService(AppUserRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Transactional(readOnly = true)
    public List<UserSummaryDTO> listUsers() {
        return repo.findAll().stream()
                .map(u -> new UserSummaryDTO(u.getId(), u.getUsername(), u.getRoles()))
                .toList();
    }


    @Transactional(readOnly = true)
    public Page<UserSummaryDTO> listUsers(Pageable pageable) {
        return repo.findAll(pageable)
                .map(u -> new UserSummaryDTO(u.getId(), u.getUsername(), u.getRoles()));
    }


    @Transactional(readOnly = true)
    public boolean usernameExists(String username) {
        return repo.existsByUsername(username);
    }

    public AppUser registerUser(String username, String rawPassword, Set<String> roles) {
        AppUser user = new AppUser();
        user.setUsername(username);
        user.setPassword(encoder.encode(rawPassword));
        user.setRoles(roles);
        return repo.save(user);
    }
}