package net.codejava.controller;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import net.codejava.dto.PageResponse;
import net.codejava.dto.UserSummaryDTO;
import net.codejava.service.AppUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.PageRequest;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {


    private final AppUserService userService;

    public AdminController(AppUserService userService) {
        this.userService = userService;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users")
    public List<UserSummaryDTO> listUsersLegacy() {

        return userService.listUsers();
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users/page")
    public ResponseEntity<PageResponse<UserSummaryDTO>> listUsersPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {


        Pageable pageable = PageRequest.of(page, size);
        Page<UserSummaryDTO> result = userService.listUsers(pageable);
        List<UserSummaryDTO> content = result.getContent();
        return ResponseEntity.ok(
                new PageResponse<>(content, page, size, result.getTotalElements(), result.getTotalPages())
        );
    }

}
