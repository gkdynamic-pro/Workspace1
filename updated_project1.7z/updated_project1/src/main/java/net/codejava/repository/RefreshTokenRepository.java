package net.codejava.repository;

import net.codejava.model.RefreshToken;
import net.codejava.model.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for performing CRUD operations on RefreshToken entities.  Provides
 * a convenient way to look up tokens by their string value and to remove
 * tokens belonging to a particular user on logout or token rotation.
 */
@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    /**
     * Return an optional RefreshToken by its token string.
     *
     * @param token the opaque refresh token sent by the client
     * @return the matching RefreshToken if present
     */
    Optional<RefreshToken> findByToken(String token);

    /**
     * Delete all refresh tokens belonging to the given user.  Useful on
     * logout or when rotating a token.
     *
     * @param user the user whose tokens should be removed
     * @return the number of tokens removed
     */
    int deleteByUser(AppUser user);
}