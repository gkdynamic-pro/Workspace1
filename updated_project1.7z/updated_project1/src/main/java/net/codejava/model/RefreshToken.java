package net.codejava.model;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entity for storing refresh tokens associated with a user.  A refresh token
 * is a random string that allows a client to obtain a new access (JWT) token
 * without re‑authenticating.  Each refresh token has its own expiry and is
 * persisted in the database so that expired or revoked tokens can be
 * invalidated server‑side.  Tokens are related to a user via a foreign key.
 */
@Entity
@Table(name = "refresh_tokens", indexes = {
        @Index(columnList = "token", unique = true)
})
public class RefreshToken {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * The opaque refresh token string.  This value is returned to the client
     * via an HTTP cookie and must be kept secret.  It is unique in the
     * database.
     */
    @Column(nullable = false, unique = true, length = 200)
    private String token;

    /**
     * The time at which this refresh token expires.  Once this date is in
     * the past the token is considered invalid and will be deleted on
     * verification.  The cookie storing the token will be configured with a
     * max age matching this expiry.
     */
    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date expiryDate;

    /**
     * The user that owns this refresh token.  Multiple tokens per user are
     * allowed to enable concurrent sessions, but during refresh the old
     * token is removed and replaced with a new one.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private AppUser user;

    public RefreshToken() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public AppUser getUser() {
        return user;
    }

    public void setUser(AppUser user) {
        this.user = user;
    }
}