package net.codejava.service;

import net.codejava.model.AppUser;
import net.codejava.model.RefreshToken;
import net.codejava.repository.AppUserRepository;
import net.codejava.repository.RefreshTokenRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

/**
 * Service responsible for creating, validating and invalidating refresh tokens.
 * A refresh token provides long‑term authentication and can be exchanged for
 * new access tokens without re‑entering credentials.  Tokens are stored in
 * the database with an expiry and tied to a specific user.
 */
@Service
@Transactional
public class RefreshTokenService {

    private final RefreshTokenRepository tokenRepository;
    private final AppUserRepository userRepository;

    /**
     * Lifetime of a refresh token in milliseconds.  Defaulted via
     * application properties but falls back to seven days if not set.
     */
    private final long refreshExpirationMs;

    public RefreshTokenService(RefreshTokenRepository tokenRepository,
                               AppUserRepository userRepository,
                               @Value("${app.refresh-expiration-ms:604800000}") long refreshExpirationMs) {
        this.tokenRepository = tokenRepository;
        this.userRepository = userRepository;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    /**
     * Create a new refresh token for the given username.  Any existing
     * refresh tokens for the user are removed before a new one is created.
     *
     * @param username the user name for whom to create the token
     * @return the persisted RefreshToken
     */
    public RefreshToken createRefreshToken(String username) {
        AppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Cannot find user: " + username));
        // Remove any existing refresh tokens to enforce one active token per user
        tokenRepository.deleteByUser(user);

        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setUser(user);
        refreshToken.setExpiryDate(new Date(System.currentTimeMillis() + refreshExpirationMs));
        refreshToken.setToken(UUID.randomUUID().toString());
        return tokenRepository.save(refreshToken);
    }

    /**
     * Find a refresh token by its token string.
     *
     * @param token the opaque token
     * @return optional containing the token if found
     */
    @Transactional(readOnly = true)
    public Optional<RefreshToken> findByToken(String token) {
        return tokenRepository.findByToken(token);
    }

    /**
     * Validate whether the given refresh token has not expired.  If the token
     * is expired it will be removed from the repository.  Callers should
     * check the returned boolean and act accordingly.
     *
     * @param token the refresh token to validate
     * @return true if the token is still valid; false if expired and deleted
     */
    public boolean verifyExpiration(RefreshToken token) {
        if (token.getExpiryDate().before(new Date())) {
            tokenRepository.delete(token);
            return false;
        }
        return true;
    }

    /**
     * Remove all refresh tokens belonging to the given user.  Used on
     * logout to invalidate any outstanding refresh tokens.
     *
     * @param user the user whose tokens should be removed
     */
    public void deleteTokensByUser(AppUser user) {
        tokenRepository.deleteByUser(user);
    }

    /**
     * Remove a specific refresh token by its token string.  Useful when the
     * token value is known, such as from an HTTP cookie, but the user is
     * not authenticated.
     *
     * @param token the token string
     */
    public void deleteByToken(String token) {
        tokenRepository.findByToken(token).ifPresent(tokenRepository::delete);
    }
}