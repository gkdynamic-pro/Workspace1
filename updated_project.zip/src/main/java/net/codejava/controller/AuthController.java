package net.codejava.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.codejava.util.JwtUtil;
import net.codejava.service.TokenBlacklistService;
import net.codejava.service.RefreshTokenService;
import net.codejava.model.AppUser;
import net.codejava.model.RefreshToken;
import net.codejava.repository.AppUserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.HashSet;
import java.util.Set;

@RestController
@RequestMapping
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final TokenBlacklistService tokenBlacklistService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder encoder;
    private final AppUserRepository userRepository;
    private final RefreshTokenService refreshTokenService;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil,
                          PasswordEncoder encoder,
                          AppUserRepository userRepository,
                          TokenBlacklistService tokenBlacklistService,
                          RefreshTokenService refreshTokenService){
        this.authenticationManager = authenticationManager;
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtUtil = jwtUtil;
        this.encoder = encoder;
        this.userRepository = userRepository;
        this.refreshTokenService = refreshTokenService;
    }

    // ---------- LOGIN ----------
    /**
     * Authenticate a user and issue both an access (JWT) token and a refresh token.
     * The refresh token is persisted in the database and returned to the client
     * via an HTTP‑only cookie.  The cookie's lifetime matches the refresh
     * token expiry.  The access token is returned in the response body.
     */
    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponse> authenticate(@RequestBody AuthRequest request,
                                                     jakarta.servlet.http.HttpServletResponse response) {
        Authentication auth;
        try {
            auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(401).build();
        }
        // Generate short‑lived access token
        String accessToken = jwtUtil.generateToken(request.getUsername());
        // Generate and persist refresh token
        RefreshToken refreshToken = refreshTokenService.createRefreshToken(request.getUsername());
        // Send refresh token to client via HttpOnly cookie
        jakarta.servlet.http.Cookie cookie = new jakarta.servlet.http.Cookie("refreshToken", refreshToken.getToken());
        cookie.setHttpOnly(true);
        // Set secure flag only if your application uses HTTPS; set to false for development
        cookie.setSecure(false);
        cookie.setPath("/");
        long maxAgeSeconds = Math.max(1L,
                (refreshToken.getExpiryDate().getTime() - System.currentTimeMillis()) / 1000);
        cookie.setMaxAge((int) maxAgeSeconds);
        response.addCookie(cookie);
        return ResponseEntity.ok(new AuthResponse(accessToken));
    }

    // ---------- SIGNUP ----------
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest().body(new Message("Username already taken"));
        }
        Set<String> roles = request.getRoles();
        if (roles == null || roles.isEmpty()) {
            roles = new HashSet<>();
            roles.add("USER");
        }
        AppUser user = new AppUser();
        user.setUsername(request.getUsername());
        user.setPassword(encoder.encode(request.getPassword())); // BCrypt hash
        user.setRoles(roles);
        userRepository.save(user);
        return ResponseEntity.ok(new Message("User registered successfully"));
    }

    // ---------- DTOs ----------
    @Data
    static class AuthRequest {
        private String username;
        private String password;
    }

    @Data
    @AllArgsConstructor
    static class AuthResponse {
        private String jwt;
    }

    @Data
    static class SignupRequest {
        private String username;
        private String password;
        private Set<String> roles;
    }

    @Data
    @AllArgsConstructor
    static class Message {
        private String message;
    }


    /**
     * Log the user out by blacklisting the current access token and removing
     * any refresh token cookie and database record.  The access token is
     * extracted from the Authorization header and stored in Redis until
     * expiry so that it cannot be used again.  The refresh token is read
     * from the cookie and deleted from the database.
     */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request,
                                    jakarta.servlet.http.HttpServletResponse response) {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().body(new Message("Missing Authorization header"));
        }
        String token = auth.substring(7);

        // Prefer JTI; fallback to token hash
        String jti = jwtUtil.extractJti(token);
        java.util.Date exp = jwtUtil.getExpirationDate(token);
        long ttlSeconds = Math.max(0, (exp.getTime() - System.currentTimeMillis()) / 1000);

        String key = "bl:access:" + (jti != null ? jti : Integer.toHexString(token.hashCode()));
        tokenBlacklistService.blacklist(key, ttlSeconds);

        // Remove refresh token from repository and clear cookie
        jakarta.servlet.http.Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (jakarta.servlet.http.Cookie c : cookies) {
                if ("refreshToken".equals(c.getName())) {
                    String refreshTokenValue = c.getValue();
                    refreshTokenService.deleteByToken(refreshTokenValue);
                    // expire the cookie immediately
                    jakarta.servlet.http.Cookie deleteCookie = new jakarta.servlet.http.Cookie("refreshToken", "");
                    deleteCookie.setHttpOnly(true);
                    deleteCookie.setSecure(false);
                    deleteCookie.setPath("/");
                    deleteCookie.setMaxAge(0);
                    response.addCookie(deleteCookie);
                    break;
                }
            }
        }
        return ResponseEntity.ok(new Message("Logged out"));
    }

    /**
     * Exchange a valid refresh token for a new access token.  The client must
     * present its refresh token via the "refreshToken" cookie.  If valid and
     * not expired, a new access token is generated and a fresh refresh token
     * is rotated and persisted.  The old refresh token is removed.  If the
     * cookie is missing, the token does not exist, or it has expired, this
     * endpoint returns 403 Forbidden.
     *
     * @param request the HTTP request containing cookies
     * @param response the response used to send back the new refresh cookie
     * @return AuthResponse containing the new access token on success
     */
    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refresh(HttpServletRequest request,
                                                jakarta.servlet.http.HttpServletResponse response) {
        jakarta.servlet.http.Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return ResponseEntity.status(403).build();
        }
        for (jakarta.servlet.http.Cookie c : cookies) {
            if ("refreshToken".equals(c.getName())) {
                String refreshTokenValue = c.getValue();
                java.util.Optional<RefreshToken> opt = refreshTokenService.findByToken(refreshTokenValue);
                if (opt.isEmpty()) {
                    return ResponseEntity.status(403).build();
                }
                RefreshToken rt = opt.get();
                if (!refreshTokenService.verifyExpiration(rt)) {
                    return ResponseEntity.status(403).build();
                }
                String username = rt.getUser().getUsername();
                String newAccessToken = jwtUtil.generateToken(username);
                // rotate refresh token
                RefreshToken newRt = refreshTokenService.createRefreshToken(username);
                jakarta.servlet.http.Cookie newCookie = new jakarta.servlet.http.Cookie("refreshToken", newRt.getToken());
                newCookie.setHttpOnly(true);
                newCookie.setSecure(false);
                newCookie.setPath("/");
                long newMaxAge = Math.max(1L,
                        (newRt.getExpiryDate().getTime() - System.currentTimeMillis()) / 1000);
                newCookie.setMaxAge((int) newMaxAge);
                response.addCookie(newCookie);
                return ResponseEntity.ok(new AuthResponse(newAccessToken));
            }
        }
        return ResponseEntity.status(403).build();
    }

}
