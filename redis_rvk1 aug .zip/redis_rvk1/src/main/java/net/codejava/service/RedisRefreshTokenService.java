package net.codejava.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class RedisRefreshTokenService {

    private final StringRedisTemplate redis;
    private final ObjectMapper om = new ObjectMapper();

    private final long refreshExpirationMs;

    public RedisRefreshTokenService(StringRedisTemplate redis,
                                    @Value("${app.refresh-expiration-ms:2592000000}") long refreshExpirationMs) {
        this.redis = redis;
        this.refreshExpirationMs = refreshExpirationMs;
    }

    private static String keyRT(String rt) { return "rt:" + rt; }
    private static String keyUserRT(String username) { return "user:rt:" + username; }

    public String createRefreshToken(String username) {
        // rotate previous
        String old = redis.opsForValue().get(keyUserRT(username));
        if (old != null) {
            redis.delete(keyRT(old));
        }
        String rt = UUID.randomUUID().toString();
        long exp = System.currentTimeMillis() + refreshExpirationMs;
        Map<String, Object> rec = new HashMap<>();
        rec.put("sub", username);
        rec.put("exp", exp);
        rec.put("revoked", 0);
        rec.put("familyId", UUID.randomUUID().toString());

        String json;
        try { json = om.writeValueAsString(rec); } catch (Exception e) { throw new RuntimeException(e); }

        long ttlSec = Math.max(1, refreshExpirationMs / 1000);
        redis.opsForValue().set(keyRT(rt), json, Duration.ofSeconds(ttlSec));
        redis.opsForValue().set(keyUserRT(username), rt, Duration.ofSeconds(ttlSec));
        return rt;
    }

    public Map<String, Object> findRecord(String rt) {
        try {
            String json = redis.opsForValue().get(keyRT(rt));
            if (json == null) return null;
            return om.readValue(json, Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean verifyExpiration(Map<String, Object> rec) {
        if (rec == null) return false;
        Object expObj = rec.get("exp");
        if (!(expObj instanceof Number)) return false;
        long exp = ((Number) expObj).longValue();
        if (exp < System.currentTimeMillis()) {
            // record TTL will naturally expire; proactively delete
            String username = (String) rec.get("sub");
            String current = redis.opsForValue().get(keyUserRT(username));
            if (current != null) {
                redis.delete(keyRT(current));
                redis.delete(keyUserRT(username));
            }
            return false;
        }
        return true;
    }

    public String rotate(String rt) {
        Map<String, Object> rec = findRecord(rt);
        if (rec == null) return null;

        // reuse detection: if already revoked -> nuke family's current pointer
        int revoked = ((Number) rec.getOrDefault("revoked", 0)).intValue();
        String username = (String) rec.get("sub");

        // mark old as revoked
        rec.put("revoked", 1);
        try {
            long exp = ((Number) rec.get("exp")).longValue();
            long ttlLeft = Math.max(1, (exp - System.currentTimeMillis()) / 1000);
            redis.opsForValue().set(keyRT(rt), om.writeValueAsString(rec), Duration.ofSeconds(ttlLeft));
        } catch (Exception ignored) {}

        if (revoked == 1) {
            // if someone tries to reuse an old token, invalidate pointer
            String current = redis.opsForValue().get(keyUserRT(username));
            if (current != null) {
                redis.delete(keyRT(current));
                redis.delete(keyUserRT(username));
            }
            return null;
        }

        // issue new
        String newRt = UUID.randomUUID().toString();
        long exp = System.currentTimeMillis() + refreshExpirationMs;
        Map<String, Object> newRec = new HashMap<>();
        newRec.put("sub", username);
        newRec.put("exp", exp);
        newRec.put("revoked", 0);
        newRec.put("familyId", rec.get("familyId"));

        try {
            long ttlSec = Math.max(1, refreshExpirationMs / 1000);
            redis.opsForValue().set(keyRT(newRt), om.writeValueAsString(newRec), Duration.ofSeconds(ttlSec));
            redis.opsForValue().set(keyUserRT(username), newRt, Duration.ofSeconds(ttlSec));
        } catch (Exception e) {
            return null;
        }
        return newRt;
    }

    public void deleteByToken(String rt) {
        Map<String, Object> rec = findRecord(rt);
        if (rec != null) {
            String username = (String) rec.get("sub");
            String current = redis.opsForValue().get(keyUserRT(username));
            if (rt.equals(current)) {
                redis.delete(keyUserRT(username));
            }
        }
        redis.delete(keyRT(rt));
    }
}
