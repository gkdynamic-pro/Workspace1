package net.codejava.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.codejava.service.TokenBlacklistService;
import net.codejava.util.JwtUtil;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

    private final JwtUtil jwt;
    private final UserDetailsService uds;
    private final TokenBlacklistService blacklist;

    public JwtFilter(JwtUtil jwt, UserDetailsService uds, TokenBlacklistService blacklist) {
        this.jwt = jwt;
        this.uds = uds;
        this.blacklist = blacklist;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        String h = req.getHeader("Authorization");
        if (h != null && h.startsWith("Bearer ")) {
            String token = h.substring(7);

            // validate the token first – this will return false for expired or malformed tokens
            boolean valid = jwt.validateToken(token);

            // Attempt to extract the JTI only if the token is valid. If the token has expired,
            // calling extractJti would throw an exception. In that case we fall back to using
            // the token's hash code for blacklist key generation.
            String jti = null;
            if (valid) {
                try {
                    jti = jwt.extractJti(token);
                } catch (io.jsonwebtoken.JwtException | IllegalArgumentException ex) {
                    // if parsing fails for any reason, we'll keep jti as null and treat the token as invalid
                    valid = false;
                }
            }
            String key = "bl:access:" + (jti != null ? jti : Integer.toHexString(token.hashCode()));

            // Only set the security context if the token is both valid and not blacklisted
            if (valid && !blacklist.isBlacklisted(key)) {
                String username = jwt.extractUsername(token);
                UserDetails user = uds.loadUserByUsername(username);
                var authToken = new UsernamePasswordAuthenticationToken(
                        user, null, user.getAuthorities());
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }
        chain.doFilter(req, res);
    }
}
