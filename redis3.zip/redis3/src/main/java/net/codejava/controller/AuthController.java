package net.codejava.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.codejava.service.AppUserService;
import net.codejava.service.TokenBlacklistService;
import net.codejava.service.RedisRefreshTokenService;
import net.codejava.util.JwtUtil;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;

@RestController
@RequestMapping   // base path unchanged -> endpoints at root
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final TokenBlacklistService tokenBlacklistService;
    private final JwtUtil jwtUtil;

    private final AppUserService appUserService;
    private final RedisRefreshTokenService redisRefreshTokenService;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil,
                          TokenBlacklistService tokenBlacklistService,
                          RedisRefreshTokenService redisRefreshTokenService,
                          AppUserService appUserService) {
        this.authenticationManager = authenticationManager;
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtUtil = jwtUtil;
        this.redisRefreshTokenService = redisRefreshTokenService;
        this.appUserService = appUserService;
    }


    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponse> authenticate(@RequestBody AuthRequest request,
                                                     HttpServletResponse response) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(401).build();
        }

        String accessToken = jwtUtil.generateToken(request.getUsername());

        String newRt = redisRefreshTokenService.createRefreshToken(request.getUsername());
        ResponseCookie rc = ResponseCookie.from("refreshToken", newRt)
                .httpOnly(true)
                .secure(false)
                .sameSite("Strict")
                .path("/")
                .maxAge(Duration.ofDays(30))
                .build();
        response.addHeader("Set-Cookie", rc.toString());

        return ResponseEntity.ok(new AuthResponse(accessToken));
    }


    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest request) {

        if (appUserService.usernameExists(request.getUsername())) {
            return ResponseEntity.badRequest().body(new Message("Username already taken"));
        }

        Set<String> roles = request.getRoles();
        if (roles == null || roles.isEmpty()) {
            roles = new HashSet<>();
            roles.add("USER");
        }
       
        appUserService.registerUser(request.getUsername(), request.getPassword(), roles);
        return ResponseEntity.ok(new Message("User registered successfully"));
    }


    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().body(new Message("Missing Authorization header"));
        }
        String token = auth.substring(7);

        String jti = null;
        java.util.Date exp = null;
        try {
            jti = jwtUtil.extractJti(token);
            exp = jwtUtil.getExpirationDate(token);
        } catch (io.jsonwebtoken.JwtException | IllegalArgumentException ignored) {}

        long ttlSeconds = 0;
        if (exp != null) {
            ttlSeconds = Math.max(0, (exp.getTime() - System.currentTimeMillis()) / 1000);
        }
        String key = "bl:access:" + (jti != null ? jti : Integer.toHexString(token.hashCode()));
        tokenBlacklistService.blacklist(key, ttlSeconds);

        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("refreshToken".equals(c.getName())) {
                    String refreshTokenValue = c.getValue();
                    redisRefreshTokenService.deleteByToken(refreshTokenValue);

                    Cookie deleteCookie = new Cookie("refreshToken", "");
                    deleteCookie.setHttpOnly(true);
                    deleteCookie.setSecure(false);
                    deleteCookie.setPath("/");
                    deleteCookie.setMaxAge(0);
                    response.addCookie(deleteCookie);
                    break;
                }
            }
        }
        return ResponseEntity.ok(new Message("Logged out"));
    }


    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refresh(HttpServletRequest request,
                                                HttpServletResponse response) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return ResponseEntity.status(403).build();

        for (Cookie c : cookies) {
            if ("refreshToken".equals(c.getName())) {
                String refreshTokenValue = c.getValue();

                var rec = redisRefreshTokenService.findRecord(refreshTokenValue);
                if (rec == null) return ResponseEntity.status(403).build();
                if (!redisRefreshTokenService.verifyExpiration(rec)) return ResponseEntity.status(403).build();

                String username = (String) rec.get("sub");
                String newAccessToken = jwtUtil.generateToken(username);

                String rotated = redisRefreshTokenService.rotate(refreshTokenValue);
                if (rotated == null) return ResponseEntity.status(403).build();

                ResponseCookie rc = ResponseCookie.from("refreshToken", rotated)
                        .httpOnly(true)
                        .secure(false)    // prod: true + HTTPS
                        .sameSite("Strict")
                        .path("/")
                        .maxAge(Duration.ofDays(30))
                        .build();
                response.addHeader("Set-Cookie", rc.toString());

                return ResponseEntity.ok(new AuthResponse(newAccessToken));
            }
        }
        return ResponseEntity.status(403).build();
    }

    //for DTOs
    @Data
    static class AuthRequest {
        private String username;
        private String password;
    }

    @Data @AllArgsConstructor
    static class AuthResponse {
        private String jwt;
    }

    @Data
    static class SignupRequest {
        private String username;
        private String password;
        private Set<String> roles;
    }

    @Data @AllArgsConstructor
    static class Message {
        private String message;
    }
}
