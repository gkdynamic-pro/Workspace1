package net.codejava.controller;

import net.codejava.dto.*;
import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import net.codejava.service.TokenBlacklistService;
import net.codejava.util.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder encoder;
    private final AppUserRepository userRepository;
    private final TokenBlacklistService blacklist;

    public AuthController(AuthenticationManager authenticationManager, JwtUtil jwtUtil, PasswordEncoder encoder,
                          AppUserRepository userRepository, TokenBlacklistService blacklist) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.encoder = encoder;
        this.userRepository = userRepository;
        this.blacklist = blacklist;
    }

    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponse> authenticate(@RequestBody AuthRequest req) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
        String token = jwtUtil.generateToken(req.getUsername());
        return ResponseEntity.ok(new AuthResponse(token));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest req) {
        if (userRepository.existsByUsername(req.getUsername())) {
            return ResponseEntity.badRequest().body("Username already exists");
        }
        AppUser u = new AppUser(null, req.getUsername(), encoder.encode(req.getPassword()), "ROLE_USER");
        userRepository.save(u);
        return ResponseEntity.ok("User created");
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Authorization") String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().body("Missing Authorization header");
        }
        String token = authHeader.substring(7);
        Date exp = jwtUtil.getExpirationDate(token);
        long until = exp != null ? exp.getTime() : (System.currentTimeMillis() + 60_000);
        blacklist.blacklist(token, until);
        return ResponseEntity.ok("Logged out");
    }
}
