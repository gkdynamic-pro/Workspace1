package net.codejava.controller;

import net.codejava.dto.StudentDTO;
import net.codejava.service.StudentService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    @GetMapping
    public List<StudentDTO> all(Authentication auth) {
        return service.all(auth.getName());
    }

    @GetMapping("{id}")
    public Optional<StudentDTO> one(Authentication auth, @PathVariable Long id) {
        return service.one(auth.getName(), id);
    }

    @PostMapping
    public StudentDTO create(Authentication auth, @RequestBody StudentDTO dto) {
        return service.create(auth.getName(), dto);
    }

    @PutMapping("{id}")
    public Optional<StudentDTO> update(Authentication auth, @PathVariable Long id, @RequestBody StudentDTO dto) {
        return service.update(auth.getName(), id, dto);
    }

    @DeleteMapping("{id}")
    public boolean delete(Authentication auth, @PathVariable Long id) {
        return service.delete(auth.getName(), id);
    }
}
