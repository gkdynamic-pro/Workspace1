package net.codejava.controller;

import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AppUserRepository repo;

    public AdminController(AppUserRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<AppUser>> users() {
        return ResponseEntity.ok(repo.findAll());
    }
}
