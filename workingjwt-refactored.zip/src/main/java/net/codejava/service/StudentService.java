package net.codejava.service;

import net.codejava.dto.StudentDTO;
import net.codejava.model.Student;
import net.codejava.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    private final StudentRepository repo;

    public StudentService(StudentRepository repo) {
        this.repo = repo;
    }

    public List<StudentDTO> all(String owner) {
        return repo.findByOwnerUsername(owner).stream()
                .map(s -> new StudentDTO(s.getId(), s.getName(), s.getAge(), s.getEmail()))
                .toList();
    }

    public Optional<StudentDTO> one(String owner, Long id) {
        return repo.findByIdAndOwnerUsername(id, owner)
                .map(s -> new StudentDTO(s.getId(), s.getName(), s.getAge(), s.getEmail()));
    }

    @Transactional
    public StudentDTO create(String owner, StudentDTO dto) {
        if (dto.getName() == null || dto.getName().isBlank()) throw new IllegalArgumentException("Name required");
        if (dto.getAge() < 0) throw new IllegalArgumentException("Age must be >= 0");
        Student s = new Student(null, dto.getName(), dto.getAge(), dto.getEmail(), owner);
        s = repo.save(s);
        return new StudentDTO(s.getId(), s.getName(), s.getAge(), s.getEmail());
    }

    @Transactional
    public Optional<StudentDTO> update(String owner, Long id, StudentDTO dto) {
        return repo.findByIdAndOwnerUsername(id, owner).map(s -> {
            if (dto.getName() != null && !dto.getName().isBlank()) s.setName(dto.getName());
            if (dto.getAge() > 0) s.setAge(dto.getAge());
            if (dto.getEmail() != null && !dto.getEmail().isBlank()) s.setEmail(dto.getEmail());
            return new StudentDTO(s.getId(), s.getName(), s.getAge(), s.getEmail());
        });
    }

    @Transactional
    public boolean delete(String owner, Long id) {
        return repo.findByIdAndOwnerUsername(id, owner).map(s -> { repo.delete(s); return true; }).orElse(false);
    }
}
