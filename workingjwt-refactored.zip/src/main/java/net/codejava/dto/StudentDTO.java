package net.codejava.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class StudentDTO {
    private Long id;
    private String name;
    private int age;
    private String email;
}
