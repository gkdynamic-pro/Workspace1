package net.codejava.config;

import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SeedConfig {

    @Bean
    CommandLineRunner seedUsers(AppUserRepository repo, PasswordEncoder enc) {
        return args -> {
            if (!repo.existsByUsername("admin")) {
                repo.save(new AppUser(null, "admin", enc.encode("admin123"), "ROLE_ADMIN,ROLE_USER"));
            }
            if (!repo.existsByUsername("user")) {
                repo.save(new AppUser(null, "user", enc.encode("user123"), "ROLE_USER"));
            }
        };
    }
}
