package net.codejava.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.codejava.util.JwtUtil;
import net.codejava.service.TokenBlacklistService;
import net.codejava.model.AppUser;
import net.codejava.repository.AppUserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.HashSet;
import java.util.Set;

@RestController
@RequestMapping
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final TokenBlacklistService tokenBlacklistService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder encoder;
    private final AppUserRepository userRepository;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtUtil jwtUtil,
                          PasswordEncoder encoder,
                          AppUserRepository userRepository, TokenBlacklistService tokenBlacklistService){
        this.authenticationManager = authenticationManager;
        this.tokenBlacklistService = tokenBlacklistService;
        this.jwtUtil = jwtUtil;
        this.encoder = encoder;
        this.userRepository = userRepository;
    }

    // ---------- LOGIN ----------
    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponse> authenticate(@RequestBody AuthRequest request) {
        Authentication auth;
        try {
            auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(401).build();
        }
        String token = jwtUtil.generateToken(request.getUsername());
        return ResponseEntity.ok(new AuthResponse(token));
    }

    // ---------- SIGNUP ----------
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest().body(new Message("Username already taken"));
        }
        Set<String> roles = request.getRoles();
        if (roles == null || roles.isEmpty()) {
            roles = new HashSet<>();
            roles.add("USER");
        }
        AppUser user = new AppUser();
        user.setUsername(request.getUsername());
        user.setPassword(encoder.encode(request.getPassword())); // BCrypt hash
        user.setRoles(roles);
        userRepository.save(user);
        return ResponseEntity.ok(new Message("User registered successfully"));
    }

    // ---------- DTOs ----------
    @Data
    static class AuthRequest {
        private String username;
        private String password;
    }

    @Data
    @AllArgsConstructor
    static class AuthResponse {
        private String jwt;
    }

    @Data
    static class SignupRequest {
        private String username;
        private String password;
        private Set<String> roles;
    }

    @Data
    @AllArgsConstructor
    static class Message {
        private String message;
    }


    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        String auth = request.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            return ResponseEntity.badRequest().body(new Message("Missing Authorization header"));
        }
        String token = auth.substring(7);

        // Prefer JTI; fallback to token hash
        String jti = jwtUtil.extractJti(token);                 // add method in JwtUtil (below)
        java.util.Date exp = jwtUtil.getExpirationDate(token);  // you already have this
        long ttlSeconds = Math.max(0, (exp.getTime() - System.currentTimeMillis()) / 1000);

        String key = "bl:access:" + (jti != null ? jti : Integer.toHexString(token.hashCode()));
        tokenBlacklistService.blacklist(key, ttlSeconds);       // <-- TTL seconds, not absolute millis

        return ResponseEntity.ok(new Message("Logged out"));
    }

}
